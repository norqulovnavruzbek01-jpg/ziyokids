import express from "express";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
app.use(express.json());

const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({
  apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
}) : null;

// Fallback AI tutor responses in Uzbek
const getFallbackTutorReply = (message: string, subject: string) => {
  const lower = message.toLowerCase();
  if (lower.includes('salom') || lower.includes('assalomu')) {
    return `Assalomu alaykum! ZiyoKids AI ustozingiz xizmatingizda. Bugun ${subject || "fan"} bo'yicha qanday qiziqarli savolingiz bor?`;
  }
  if (subject.toLowerCase().includes('matematika')) {
    return `Matematika - fanlar malikasi! "${message}" savolingiz bo'yicha shuni aytishim mumkinki: masalani yechishda avval berilgan qiymatlarni yozib oling va formulani to'g'ri tanlang. Qaysi bosqichda qiynalayapsiz?`;
  }
  if (subject.toLowerCase().includes('fizika')) {
    return `Fizika atrofimizdagi olam qonunlarini tushuntiradi. "${message}" savolingiz bo'yicha tabiat hodisalarida doim sabab va oqibat bog'liqligi borligini unutmaslik kerak!`;
  }
  return `"${message}" savolingiz juda qiziqarli! ${subject} fanida bu mavzuni chuqurroq o'rganish uchun darslikdagi misollarni ko'rib chiqish va amalda sinab ko'rish muhim. Yana qanday savolingiz bor?`;
};

// Fallback quiz generator
const getFallbackQuiz = (subject: string) => {
  return [
    {
      id: 1,
      question: `${subject} fanidan bilimingizni tekshiruvchi asosiy savol: Bu mavzuning eng muhim qoidasi nima?`,
      options: ["Qonuniyatni to'g'ri tushunish", "Faqat yodlash", "Tasodifiy tanlash", "Hech qanday ahamiyati yo'q"],
      correctIndex: 0,
      explanation: "Har qanday fanda qoida va qonuniyatlarni mantiqiy tushunish yodlashdan ko'ra muhimroqdir."
    },
    {
      id: 2,
      question: `Quyidagilardan qaysi biri ${subject} faniga tegishli asosiy tushuncha hisoblanadi?`,
      options: ["Amaliy qoidalar va masalalar", "Faqat she'rlar", "Musiqa notalari", "Sport mashqlari"],
      correctIndex: 0,
      explanation: "Bu fan o'zining aniq qoidalari va amaliy misollariga ega."
    }
  ];
};

// AI Tutor endpoint
app.post("/api/ai-tutor", async (req, res) => {
  try {
    const { message, subject, ageGroup } = req.body;
    if (!ai) {
      // Offline fallback
      return res.json({ reply: getFallbackTutorReply(message || "", subject || "umumiy") });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: message,
      config: {
        systemInstruction: `Siz ZiyoKids platformasining aqlli va mehrli sun'iy intellekt ustozi-maslahatchisisiz. Siz bolalarga (${ageGroup || "8-14 yosh"}) ${subject || "barcha fanlar"} bo'yicha ilhomlantiruvchi, tushunarli, qiziqarli va hayotiy misollar bilan to'la o'zbek tilida javob berasiz.`,
      }
    });
    res.json({ reply: response.text || getFallbackTutorReply(message || "", subject || "") });
  } catch (error: any) {
    console.warn("AI Tutor API warning, using fallback:", error?.message);
    const { message, subject } = req.body;
    res.json({ reply: getFallbackTutorReply(message || "", subject || "") });
  }
});

// AI Quiz Generator endpoint
app.post("/api/generate-quiz", async (req, res) => {
  try {
    const { subject, level = "o'rta", count = 5 } = req.body;
    if (!ai) {
      return res.json({ quiz: getFallbackQuiz(subject || "Fan") });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `${subject} fanidan ${level} darajadagi bolalar uchun ${count} ta qiziqarli test savoli tuzing.`,
      config: {
        systemInstruction: `Siz professional pedagog va o'quv dasturi tuzuvchisiz. O'zbek tilida JSON massiv shaklida aniq ${count} ta test savolini quyidagi sxemaga muvofiq qaytaring:
        [
          {
            "id": 1,
            "question": "Savol matni...",
            "options": ["Variant A", "Variant B", "Variant C", "Variant D"],
            "correctIndex": 0,
            "explanation": "Nima uchun bu javob to'g'riligining tushuntirishi..."
          }
        ]
        Faqat valid JSON qaytaring.`,
        responseMimeType: "application/json"
      }
    });
    const jsonStr = (response.text ?? "[]").trim();
    const quiz = JSON.parse(jsonStr);
    res.json({ quiz });
  } catch (error: any) {
    console.warn("Quiz Gen API warning, using fallback:", error?.message);
    const { subject } = req.body;
    res.json({ quiz: getFallbackQuiz(subject || "Fan") });
  }
});

async function startServer() {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

startServer();
