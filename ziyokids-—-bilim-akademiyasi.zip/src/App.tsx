/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Calculator, BookOpen, Feather, Cpu, Globe, Landmark, Compass, Map, Zap,
  Flame, Award, Star, BookMarked, MessageSquareText, ShieldAlert,
  ChevronRight, ArrowLeft, CheckCircle2, XCircle, RotateCcw, Send, Sparkles,
  UserCheck, BarChart3, Clock, Check, HelpCircle, Lightbulb, Play, User, Lock, Phone, Mail, LogOut, ShieldCheck, Users, Trash2
} from 'lucide-react';
import { SUBJECTS } from './data/curriculum';
import { SubjectInfo, Topic, QuizQuestion, SubjectId, UserProfile } from './types';

// Helper for dynamic icon rendering
const SubjectIcon = ({ name, className }: { name: string; className?: string }) => {
  switch (name) {
    case 'Calculator': return <Calculator className={className} />;
    case 'BookOpen': return <BookOpen className={className} />;
    case 'Feather': return <Feather className={className} />;
    case 'Cpu': return <Cpu className={className} />;
    case 'Globe': return <Globe className={className} />;
    case 'Landmark': return <Landmark className={className} />;
    case 'Compass': return <Compass className={className} />;
    case 'Map': return <Map className={className} />;
    case 'Zap': return <Zap className={className} />;
    default: return <BookMarked className={className} />;
  }
};

export default function App() {
  // Auth state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('ziyokids_current_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [regForm, setRegForm] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    email: '',
    username: '',
    password: ''
  });
  const [loginForm, setLoginForm] = useState({
    username: '',
    password: ''
  });
  const [authError, setAuthError] = useState<string | null>(null);

  // Admin state
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState<string>('');
  const [showAdminModal, setShowAdminModal] = useState<boolean>(false);
  const [adminError, setAdminError] = useState<string | null>(null);

  // App navigation & state
  const [activeTab, setActiveTab] = useState<'home' | 'subject' | 'lesson' | 'ai-tutor' | 'parent' | 'admin'>('home');
  const [selectedSubject, setSelectedSubject] = useState<SubjectInfo | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  // Gamification state (0 for new users)
  const [xp, setXp] = useState<number>(currentUser?.xp ?? 0);
  const [streak, setStreak] = useState<number>(currentUser?.streak ?? 1);
  const [completedLessons, setCompletedLessons] = useState<string[]>(currentUser?.completedLessons || []);

  // Quiz state
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [aiQuiz, setAiQuiz] = useState<QuizQuestion[] | null>(null);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState<boolean>(false);

  // AI Tutor state
  const [chatMessages, setChatMessages] = useState<Array<{role: 'user' | 'assistant', text: string}>>([
    { role: 'assistant', text: "Assalomu alaykum! Men Ziyo AI, sizning shaxsiy o'qituvchingizman. Qaysi fan yoki masala bo'yicha savolingiz bor?" }
  ]);
  const [chatInput, setChatInput] = useState<string>('');
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [tutorSubject, setTutorSubject] = useState<string>('Matematika');

  // Notification state
  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Sync user state to localStorage
  useEffect(() => {
    if (currentUser) {
      const updated = { ...currentUser, xp, streak, completedLessons };
      localStorage.setItem('ziyokids_current_user', JSON.stringify(updated));
      try {
        const usersDb = JSON.parse(localStorage.getItem('ziyokids_users_db') || '[]');
        const index = usersDb.findIndex((u: UserProfile) => u.username === currentUser.username);
        if (index !== -1) {
          usersDb[index] = updated;
          localStorage.setItem('ziyokids_users_db', JSON.stringify(usersDb));
        } else {
          usersDb.push(updated);
          localStorage.setItem('ziyokids_users_db', JSON.stringify(usersDb));
        }
      } catch (e) {
        console.error("Storage error:", e);
      }
    }
  }, [xp, streak, completedLessons]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    const fName = regForm.firstName.trim();
    const lName = regForm.lastName.trim();
    const phone = regForm.phone.trim();
    const email = regForm.email.trim();
    const username = regForm.username.trim();
    const password = regForm.password;

    if (!fName || !lName || !phone || !email || !username || !password) {
      setAuthError("Iltimos, barcha maydonlarni to'ldiring!");
      return;
    }

    if (password.length < 4) {
      setAuthError("Parol kamida 4 ta belgidan iborat bo'lishi kerak.");
      return;
    }

    try {
      const usersDb = JSON.parse(localStorage.getItem('ziyokids_users_db') || '[]');
      const existing = usersDb.find((u: UserProfile) => u.username === username);
      if (existing) {
        setAuthError("Bu login allaqachon band qilingan. Boshqa login tanlang.");
        return;
      }

      const newUser: UserProfile = {
        firstName: fName,
        lastName: lName,
        phone,
        email,
        username,
        password,
        xp: 0,
        streak: 1,
        completedLessons: []
      };

      usersDb.push(newUser);
      localStorage.setItem('ziyokids_users_db', JSON.stringify(usersDb));
      localStorage.setItem('ziyokids_current_user', JSON.stringify(newUser));

      setCurrentUser(newUser);
      setXp(0);
      setStreak(1);
      setCompletedLessons([]);
      showNotification("Muvaffaqiyatli ro'yxatdan o'tdingiz! Xush kelibsiz 🎉");
    } catch (err) {
      console.error(err);
      setAuthError("Ro'yxatdan o'tishda xatolik yuz berdi.");
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    const username = loginForm.username.trim();
    const password = loginForm.password;

    if (!username || !password) {
      setAuthError("Login va parolni kiriting!");
      return;
    }

    try {
      const usersDb = JSON.parse(localStorage.getItem('ziyokids_users_db') || '[]');
      const found = usersDb.find((u: UserProfile) => u.username === username && u.password === password);

      if (!found) {
        setAuthError("Login yoki parol xato!");
        return;
      }

      setCurrentUser(found);
      setXp(found.xp ?? 0);
      setStreak(found.streak ?? 1);
      setCompletedLessons(found.completedLessons || []);
      localStorage.setItem('ziyokids_current_user', JSON.stringify(found));
      showNotification(`Xush kelibsiz, ${found.firstName}! 👋`);
    } catch (err) {
      console.error(err);
      setAuthError("Tizimga kirishda xatolik yuz berdi.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('ziyokids_current_user');
    setCurrentUser(null);
    showNotification("Tizimdan chiqildi.");
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError(null);
    if (adminPasswordInput === 'navruzbeknorqulov') {
      setIsAdminLoggedIn(true);
      setShowAdminModal(false);
      setActiveTab('admin');
      setAdminPasswordInput('');
      showNotification("Admin paneliga xush kelibsiz! 🛡️");
    } else {
      setAdminError("Parol noto'g'ri!");
    }
  };

  const handleCompleteLesson = (topicId: string) => {
    if (!completedLessons.includes(topicId)) {
      setCompletedLessons([...completedLessons, topicId]);
      setXp(prev => prev + 50);
      showNotification("Tabriklaymiz! +50 XP ball qo'shildi! 🎉");
    }
  };

  const handleGenerateAiQuiz = async (subjectTitle: string) => {
    setIsGeneratingQuiz(true);
    try {
      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: subjectTitle, count: 4 })
      });
      const data = await res.json();
      if (data.quiz && Array.isArray(data.quiz)) {
        setAiQuiz(data.quiz);
        setQuizAnswers({});
        showNotification("Sun'iy intellekt maxsus test tuzdi! Sinab ko'ring 🧠");
      } else {
        throw new Error("Test yaratib bo'lmadi");
      }
    } catch (err) {
      console.error(err);
      showNotification("Test yaratishda xatolik yuz berdi. Qaytadan urinib ko'ring.");
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  const handleSendChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userText = chatInput;
    setChatInput('');
    setChatMessages(prev => [...prev, { role: 'user', text: userText }]);
    setIsChatLoading(true);

    try {
      const res = await fetch('/api/ai-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userText, subject: tutorSubject, ageGroup: '10-14 yosh' })
      });
      const data = await res.json();
      setChatMessages(prev => [...prev, { role: 'assistant', text: data.reply || "Javob topilmadi." }]);
    } catch (err) {
      console.error(err);
      setChatMessages(prev => [...prev, { role: 'assistant', text: "Kechirasiz, aloqada xatolik yuz berdi. Internetni tekshirib qayta urinib ko'ring." }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // If not logged in, show Auth Screen (Login / Register)
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-slate-900 to-violet-950 flex items-center justify-center p-6 text-slate-100 relative">
        {/* Admin Login Modal Trigger Button on Top Right */}
        <div className="absolute top-6 right-6">
          <button 
            onClick={() => setShowAdminModal(true)}
            className="px-4 py-2 bg-slate-800/80 hover:bg-slate-800 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 flex items-center gap-2 transition-colors"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            Admin Paneli
          </button>
        </div>

        {/* Admin Modal */}
        {showAdminModal && (
          <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-amber-400" />
                  Admin sifatida kirish
                </h3>
                <button onClick={() => setShowAdminModal(false)} className="text-slate-400 hover:text-white">✕</button>
              </div>
              <form onSubmit={handleAdminLogin} className="space-y-3">
                {adminError && <p className="text-xs text-rose-400">{adminError}</p>}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Admin paroli</label>
                  <input 
                    type="password"
                    placeholder="Parolni kiriting"
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-500"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Kirish
                </button>
              </form>
            </div>
          </div>
        )}

        <div className="max-w-md w-full bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-lg">
              <BookOpen className="w-7 h-7" />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight">ZiyoKids Akademiyasi</h1>
            <p className="text-xs text-slate-400">Bolalar uchun aqlli ta'lim va fanlar olami</p>
          </div>

          {/* Tab switch */}
          <div className="flex bg-slate-800 p-1 rounded-xl">
            <button 
              onClick={() => { setAuthMode('register'); setAuthError(null); }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${authMode === 'register' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Ro'yxatdan o'tish
            </button>
            <button 
              onClick={() => { setAuthMode('login'); setAuthError(null); }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors ${authMode === 'login' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Tizimga kirish
            </button>
          </div>

          {authError && (
            <div className="bg-rose-500/20 border border-rose-500/50 text-rose-200 text-xs p-3 rounded-xl flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {authMode === 'register' ? (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Ism</label>
                  <input 
                    type="text" 
                    placeholder="Ismingiz"
                    value={regForm.firstName}
                    onChange={(e) => setRegForm({...regForm, firstName: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">Familiya</label>
                  <input 
                    type="text" 
                    placeholder="Familiyangiz"
                    value={regForm.lastName}
                    onChange={(e) => setRegForm({...regForm, lastName: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Telefon raqam</label>
                <div className="relative">
                  <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="tel" 
                    placeholder="+998 90 123 45 67"
                    value={regForm.phone}
                    onChange={(e) => setRegForm({...regForm, phone: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Email manzil</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="email" 
                    placeholder="example@gmail.com"
                    value={regForm.email}
                    onChange={(e) => setRegForm({...regForm, email: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Login</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="text" 
                    placeholder="O'zingizga login tanlang"
                    value={regForm.username}
                    onChange={(e) => setRegForm({...regForm, username: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Parol</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="password" 
                    placeholder="Maxfiy parol"
                    value={regForm.password}
                    onChange={(e) => setRegForm({...regForm, password: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold rounded-xl text-xs shadow-lg transition-all"
              >
                Ro'yxatdan o'tish
              </button>
            </form>
          ) : (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Login</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="text" 
                    placeholder="Loginingizni kiriting"
                    value={loginForm.username}
                    onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-400 mb-1">Parol</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                  <input 
                    type="password" 
                    placeholder="Parolingizni kiriting"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-10 pr-3 py-2 text-xs text-white outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold rounded-xl text-xs shadow-lg transition-all"
              >
                Tizimga kirish
              </button>
            </form>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors duration-200">
      
      {/* Floating Notification */}
      {notification && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-5 py-3 rounded-xl shadow-xl flex items-center gap-3 animate-bounce">
          <Sparkles className="w-5 h-5" />
          <span className="font-medium text-sm">{notification}</span>
        </div>
      )}

      {/* Admin Modal if triggered */}
      {showAdminModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                Admin Paneli
              </h3>
              <button onClick={() => setShowAdminModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>
            {isAdminLoggedIn ? (
              <div className="space-y-4">
                <p className="text-xs text-emerald-400 font-medium">Siz allaqachon admin sifatida kirgansiz!</p>
                <button 
                  onClick={() => { setActiveTab('admin'); setShowAdminModal(false); }}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Admin paneliga o'tish
                </button>
              </div>
            ) : (
              <form onSubmit={handleAdminLogin} className="space-y-3">
                {adminError && <p className="text-xs text-rose-400">{adminError}</p>}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Admin paroli</label>
                  <input 
                    type="password"
                    placeholder="Parolni kiriting"
                    value={adminPasswordInput}
                    onChange={(e) => setAdminPasswordInput(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-500"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs transition-colors"
                >
                  Kirish
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between gap-8">
        {/* Brand */}
        <div 
          onClick={() => { setActiveTab('home'); setSelectedSubject(null); setSelectedTopic(null); }}
          className="flex items-center gap-3 cursor-pointer shrink-0 group"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-indigo-600 to-violet-600 bg-clip-text text-transparent">
              ZiyoKids
            </span>
            <span className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
              {currentUser.firstName} {currentUser.lastName}
            </span>
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button 
            onClick={() => { setActiveTab('home'); setSelectedSubject(null); setSelectedTopic(null); }}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 ${activeTab === 'home' ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
          >
            Bosh sahifa
          </button>
          <button 
            onClick={() => setActiveTab('ai-tutor')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${activeTab === 'ai-tutor' ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            AI Ustoz
          </button>
          <button 
            onClick={() => setActiveTab('parent')}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${activeTab === 'parent' ? 'text-indigo-600 dark:text-indigo-400 font-semibold border-b-2 border-indigo-600' : 'hover:text-slate-900 dark:hover:text-white'}`}
          >
            <BarChart3 className="w-4 h-4 text-emerald-500" />
            Ota-onalar paneli
          </button>
          <button 
            onClick={() => {
              if (isAdminLoggedIn) {
                setActiveTab('admin');
              } else {
                setShowAdminModal(true);
              }
            }}
            className={`transition-colors whitespace-nowrap shrink-0 py-1 flex items-center gap-1.5 ${activeTab === 'admin' ? 'text-amber-600 dark:text-amber-400 font-semibold border-b-2 border-amber-500' : 'text-slate-600 dark:text-slate-300 hover:text-amber-600'}`}
          >
            <ShieldCheck className="w-4 h-4 text-amber-500" />
            Admin Paneli
          </button>
        </nav>

        {/* User Stats & Logout */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden sm:flex items-center gap-1.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 px-3 py-1.5 rounded-lg text-amber-700 dark:text-amber-300 text-xs font-semibold tabular-nums">
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span>{streak} kun</span>
          </div>
          <div className="flex items-center gap-1.5 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 px-3 py-1.5 rounded-lg text-indigo-700 dark:text-indigo-300 text-xs font-semibold tabular-nums">
            <Star className="w-4 h-4 text-indigo-500 fill-indigo-500" />
            <span>{xp} XP</span>
          </div>
          <button 
            onClick={handleLogout}
            title="Tizimdan chiqish"
            className="p-2 bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 hover:text-rose-600 rounded-lg text-slate-600 dark:text-slate-300 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 md:p-8">
        
        {/* ================= HOME VIEW ================= */}
        {activeTab === 'home' && (
          <div className="space-y-10">
            
            {/* Hero Banner */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-600 via-violet-600 to-purple-700 p-8 md:p-12 text-white shadow-xl">
              <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10 max-w-2xl space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold tracking-wide">
                  <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                  Xush kelibsiz, {currentUser.firstName}!
                </div>
                <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight leading-tight">
                  Farzandingiz kelajagi uchun bilim maskani
                </h1>
                <p className="text-indigo-100 text-base md:text-lg leading-relaxed">
                  Matematika, informatika, fizika, tarix va tillardan zerikarli darslarsiz, interaktiv va qiziqarli tarzda bilim oling.
                </p>
                <div className="pt-2 flex flex-wrap gap-4">
                  <button 
                    onClick={() => {
                      const mathSub = SUBJECTS.find(s => s.id === 'matematika')!;
                      setSelectedSubject(mathSub);
                      setActiveTab('subject');
                    }}
                    className="px-6 py-3 bg-white text-indigo-900 font-bold rounded-xl shadow-lg hover:bg-indigo-50 transition-colors flex items-center gap-2"
                  >
                    <Play className="w-4 h-4 fill-indigo-900" />
                    Birinchi darsni boshlash
                  </button>
                  <button 
                    onClick={() => setActiveTab('ai-tutor')}
                    className="px-6 py-3 bg-indigo-800/80 backdrop-blur-md text-white font-semibold rounded-xl hover:bg-indigo-800 transition-colors border border-indigo-500/30 flex items-center gap-2"
                  >
                    <MessageSquareText className="w-4 h-4" />
                    AI Ustozdan savol so'rash
                  </button>
                </div>
              </div>
            </div>

            {/* Subject Selection Grid */}
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
                    Barcha o'quv fanlari (9 ta asosiy fan)
                  </h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                    Maktab dasturiga to'liq mos keluvchi qiziqarli mavzular va testlar
                  </p>
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Jami darslar: <span className="font-semibold text-slate-900 dark:text-white">96 ta mavzu</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {SUBJECTS.map((sub) => {
                  const completedCount = sub.topics.filter(t => completedLessons.includes(t.id)).length;
                  const progressPercent = sub.topics.length > 0 ? Math.round((completedCount / sub.topics.length) * 100) : 0;

                  return (
                    <div 
                      key={sub.id}
                      onClick={() => {
                        setSelectedSubject(sub);
                        setActiveTab('subject');
                      }}
                      className={`group relative rounded-2xl border ${sub.bgColor} p-6 cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all duration-200 flex flex-col justify-between`}
                    >
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <div className={`w-12 h-12 rounded-2xl bg-white dark:bg-slate-900 shadow-sm flex items-center justify-center ${sub.color}`}>
                            <SubjectIcon name={sub.icon} className="w-6 h-6" />
                          </div>
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            {sub.lessonsCount} ta dars
                          </span>
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
                          {sub.title}
                        </h3>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                          {sub.description}
                        </p>
                      </div>

                      <div className="mt-6 pt-4 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between text-xs font-medium">
                        <span className="text-slate-500 dark:text-slate-400">O'zlashtirish</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-600 rounded-full transition-all duration-300" style={{ width: `${progressPercent}%` }} />
                          </div>
                          <span className="text-slate-700 dark:text-slate-300 font-semibold tabular-nums">{progressPercent}%</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ================= ADMIN PANEL VIEW ================= */}
        {activeTab === 'admin' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-amber-500/10 border border-amber-500/30 p-6 rounded-3xl">
              <div>
                <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-7 h-7 text-amber-500" />
                  Admin Paneli — O'quvchilar Monitoringi
                </h1>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                  Barcha ro'yxatdan o'tgan o'quvchilar, ularning shaxsiy ma'lumotlari, qaysi fan va mavzularni o'qiyotgani hamda to'plagan XP ballarini kuzating.
                </p>
              </div>
              <button 
                onClick={() => { setIsAdminLoggedIn(false); setActiveTab('home'); showNotification("Admin panelidan chiqildi."); }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-xl text-xs transition-colors shrink-0"
              >
                Admin chiqish
              </button>
            </div>

            {/* Students Table */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm overflow-x-auto">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-500" />
                  Ro'yxatdan o'tgan o'quvchilar bazasi
                </h3>
                <span className="text-xs font-medium text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full">
                  {(() => {
                    try {
                      const db = JSON.parse(localStorage.getItem('ziyokids_users_db') || '[]');
                      return db.length + " ta o'quvchi";
                    } catch {
                      return "0 ta o'quvchi";
                    }
                  })()}
                </span>
              </div>

              <table className="w-full text-left border-collapse text-xs md:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 font-semibold">
                    <th className="pb-3 px-4">O'quvchi F.I.Sh</th>
                    <th className="pb-3 px-4">Login</th>
                    <th className="pb-3 px-4">Telefon & Email</th>
                    <th className="pb-3 px-4">To'plagan XP</th>
                    <th className="pb-3 px-4">Tugallangan darslar</th>
                    <th className="pb-3 px-4">O'qiyotgan fanlari / Holati</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {(() => {
                    try {
                      const usersDb: UserProfile[] = JSON.parse(localStorage.getItem('ziyokids_users_db') || '[]');
                      if (usersDb.length === 0) {
                        return (
                          <tr>
                            <td colSpan={6} className="py-8 text-center text-slate-500">
                              Hozircha ro'yxatdan o'tgan o'quvchilar yo'q.
                            </td>
                          </tr>
                        );
                      }
                      return usersDb.map((u, i) => {
                        const completedIds = u.completedLessons || [];
                        // Find which subjects have completed topics
                        const studiedSubjects = SUBJECTS.filter(sub => 
                          sub.topics.some(t => completedIds.includes(t.id))
                        ).map(sub => sub.title);

                        return (
                          <tr key={i} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                            <td className="py-4 px-4 font-bold text-slate-900 dark:text-white">
                              {u.firstName} {u.lastName}
                            </td>
                            <td className="py-4 px-4 font-mono text-indigo-600 dark:text-indigo-400">
                              @{u.username}
                            </td>
                            <td className="py-4 px-4 text-slate-600 dark:text-slate-300">
                              <div>{u.phone}</div>
                              <div className="text-[11px] text-slate-400">{u.email}</div>
                            </td>
                            <td className="py-4 px-4 font-semibold text-amber-600 dark:text-amber-400 tabular-nums">
                              ⭐ {u.xp ?? 0} XP
                            </td>
                            <td className="py-4 px-4 font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                              📚 {completedIds.length} ta mavzu
                            </td>
                            <td className="py-4 px-4">
                              {studiedSubjects.length > 0 ? (
                                <div className="flex flex-wrap gap-1">
                                  {studiedSubjects.map((subName, sIdx) => (
                                    <span key={sIdx} className="px-2 py-0.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded-md text-[11px] font-medium">
                                      {subName}
                                    </span>
                                  ))}
                                </div>
                              ) : (
                                <span className="text-slate-400 text-xs italic">
                                  Hali dars boshlamagan
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      });
                    } catch {
                      return (
                        <tr>
                          <td colSpan={6} className="py-8 text-center text-slate-500">
                            Ma'lumotlarni o'qishda xatolik.
                          </td>
                        </tr>
                      );
                    }
                  })()}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ================= SUBJECT DETAIL VIEW ================= */}
        {activeTab === 'subject' && selectedSubject && (
          <div className="space-y-8">
            <button 
              onClick={() => { setActiveTab('home'); setSelectedSubject(null); }}
              className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              Barcha fanlarga qaytish
            </button>

            {/* Subject Header */}
            <div className={`rounded-3xl border ${selectedSubject.bgColor} p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6`}>
              <div className="flex items-center gap-6">
                <div className={`w-16 h-16 rounded-2xl bg-white dark:bg-slate-900 shadow-md flex items-center justify-center ${selectedSubject.color}`}>
                  <SubjectIcon name={selectedSubject.icon} className="w-8 h-8" />
                </div>
                <div>
                  <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
                    {selectedSubject.title}
                  </h1>
                  <p className="text-sm text-slate-600 dark:text-slate-300 mt-1 max-w-xl">
                    {selectedSubject.description}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => handleGenerateAiQuiz(selectedSubject.title)}
                disabled={isGeneratingQuiz}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl text-xs flex items-center gap-2 shadow-md transition-colors disabled:opacity-50"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                {isGeneratingQuiz ? "Test tuzilmoqda..." : "AI orqali yangi test tuzish"}
              </button>
            </div>

            {/* AI Generated Quiz */}
            {aiQuiz && (
              <div className="bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 rounded-3xl p-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                    <h3 className="text-lg font-bold text-indigo-900 dark:text-indigo-200">
                      Sun'iy intellekt tomonidan tuzilgan maxsus test
                    </h3>
                  </div>
                  <button 
                    onClick={() => setAiQuiz(null)}
                    className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
                  >
                    Yopish
                  </button>
                </div>

                <div className="space-y-6">
                  {aiQuiz.map((q, qIndex) => {
                    const selectedOpt = quizAnswers[q.id];
                    const isAnswered = selectedOpt !== undefined;

                    return (
                      <div key={q.id} className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 space-y-3">
                        <p className="font-semibold text-slate-900 dark:text-white text-sm">
                          {qIndex + 1}. {q.question}
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {q.options.map((opt, oIndex) => {
                            let btnStyle = "border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300";
                            if (isAnswered) {
                              if (oIndex === q.correctIndex) {
                                btnStyle = "bg-emerald-50 dark:bg-emerald-950/40 border-emerald-500 text-emerald-700 dark:text-emerald-300 font-semibold";
                              } else if (selectedOpt === oIndex) {
                                btnStyle = "bg-rose-50 dark:bg-rose-950/40 border-rose-500 text-rose-700 dark:text-rose-300";
                              }
                            }

                            return (
                              <button
                                key={oIndex}
                                disabled={isAnswered}
                                onClick={() => setQuizAnswers({ ...quizAnswers, [q.id]: oIndex })}
                                className={`p-3 rounded-xl border text-xs text-left transition-all ${btnStyle}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                        {isAnswered && (
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl">
                            💡 <span className="font-semibold">Tushuntirish:</span> {q.explanation}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Topics List */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                Mavzular ro'yxati
              </h3>

              <div className="space-y-3">
                {selectedSubject.topics.map((topic, index) => {
                  const isCompleted = completedLessons.includes(topic.id);

                  return (
                    <div 
                      key={topic.id}
                      onClick={() => {
                        setSelectedTopic(topic);
                        setActiveTab('lesson');
                        setQuizAnswers({});
                      }}
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex items-center justify-between gap-4 cursor-pointer hover:border-indigo-500 dark:hover:border-indigo-500 transition-all shadow-sm"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${isCompleted ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300' : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'}`}>
                          {isCompleted ? <CheckCircle2 className="w-5 h-5" /> : index + 1}
                        </div>
                        <div>
                          <h4 className="font-bold text-slate-900 dark:text-white text-sm md:text-base">
                            {topic.title}
                          </h4>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                            {topic.summary}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-xs px-2.5 py-1 rounded-lg font-medium ${isCompleted ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300' : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/50 dark:text-indigo-300'}`}>
                          {isCompleted ? "O'zlashtirildi" : "Boshlash"}
                        </span>
                        <ChevronRight className="w-5 h-5 text-slate-400" />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ================= LESSON & QUIZ VIEW ================= */}
        {activeTab === 'lesson' && selectedSubject && selectedTopic && (
          <div className="max-w-4xl mx-auto space-y-8">
            <button 
              onClick={() => { setActiveTab('subject'); setSelectedTopic(null); }}
              className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              <ArrowLeft className="w-4 h-4" />
              Mavzularga qaytish
            </button>

            {/* Lesson Content Card */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  {selectedSubject.title} · Dars
                </span>
                <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
                  {selectedTopic.title}
                </h1>
              </div>

              <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 leading-relaxed text-sm md:text-base whitespace-pre-line bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
                {selectedTopic.content}
              </div>

              {!completedLessons.includes(selectedTopic.id) && (
                <div className="pt-4 flex justify-end">
                  <button 
                    onClick={() => handleCompleteLesson(selectedTopic.id)}
                    className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs md:text-sm flex items-center gap-2 shadow-md transition-colors"
                  >
                    <CheckCircle2 className="w-5 h-5" />
                    Darsni tugallangan deb belgilash (+50 XP)
                  </button>
                </div>
              )}
            </div>

            {/* Quiz Section */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-8 shadow-sm space-y-6">
              <div className="flex items-center gap-3">
                <HelpCircle className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Bilimingizni sinab ko'ring (Test)
                </h3>
              </div>

              <div className="space-y-6">
                {selectedTopic.quiz.map((q, qIndex) => {
                  const selectedOpt = quizAnswers[q.id];
                  const isAnswered = selectedOpt !== undefined;

                  return (
                    <div key={q.id} className="space-y-3 p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
                      <p className="font-semibold text-slate-900 dark:text-white text-sm">
                        {qIndex + 1}. {q.question}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {q.options.map((opt, oIndex) => {
                          let btnStyle = "bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-indigo-400 text-slate-700 dark:text-slate-300";
                          if (isAnswered) {
                            if (oIndex === q.correctIndex) {
                              btnStyle = "bg-emerald-100 dark:bg-emerald-950/60 border-emerald-500 text-emerald-800 dark:text-emerald-200 font-semibold";
                            } else if (selectedOpt === oIndex) {
                              btnStyle = "bg-rose-100 dark:bg-rose-950/60 border-rose-500 text-rose-800 dark:text-rose-200";
                            }
                          }

                          return (
                            <button
                              key={oIndex}
                              disabled={isAnswered}
                              onClick={() => {
                                setQuizAnswers({ ...quizAnswers, [q.id]: oIndex });
                                if (oIndex === q.correctIndex) {
                                  showNotification("To'g'ri javob! Ajoyib 🌟");
                                  setXp(prev => prev + 10);
                                }
                              }}
                              className={`p-3.5 rounded-xl border text-xs text-left transition-all ${btnStyle}`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>

                      {isAnswered && (
                        <div className="mt-2 text-xs text-slate-600 dark:text-slate-300 bg-indigo-50 dark:bg-indigo-950/40 p-3 rounded-xl border border-indigo-100 dark:border-indigo-900">
                          💡 <span className="font-semibold">Izoh:</span> {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ================= AI TUTOR VIEW ================= */}
        {activeTab === 'ai-tutor' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-gradient-to-r from-indigo-600 to-violet-600 text-white p-6 rounded-3xl shadow-md flex items-center justify-between">
              <div>
                <h1 className="text-xl md:text-2xl font-bold flex items-center gap-2">
                  <Sparkles className="w-6 h-6 text-yellow-300" />
                  Ziyo AI — Aqlli Ustoz
                </h1>
                <p className="text-xs md:text-sm text-indigo-100 mt-1">
                  Matematika, fizika, tarix yoki boshqa fanlar bo'yicha istalgan savolingizni bering!
                </p>
              </div>
              <select 
                value={tutorSubject}
                onChange={(e) => setTutorSubject(e.target.value)}
                className="bg-indigo-700 text-white border border-indigo-500 text-xs font-semibold rounded-xl px-3 py-2 outline-none"
              >
                <option value="Matematika">Matematika</option>
                <option value="Ona tili">Ona tili</option>
                <option value="Informatika">Informatika</option>
                <option value="Fizika">Fizika</option>
                <option value="Tarix">Tarix</option>
                <option value="Ingliz tili">Ingliz tili</option>
              </select>
            </div>

            {/* Chat Messages Box */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 h-[500px] flex flex-col justify-between shadow-sm">
              <div className="overflow-y-auto space-y-4 pr-2">
                {chatMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-br-sm' : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100 rounded-bl-sm'}`}>
                      {msg.text}
                    </div>
                  </div>
                ))}
                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-slate-100 dark:bg-slate-800 p-4 rounded-2xl text-xs text-slate-500 animate-pulse">
                      Ziyo AI o'ylamoqda...
                    </div>
                  </div>
                )}
              </div>

              {/* Chat Input Form */}
              <form onSubmit={handleSendChat} className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center gap-3">
                <input 
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Masalan: Nyutonning 3-qonunini oddiy tilda tushuntirib ber..."
                  className="flex-1 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4 py-3 rounded-xl text-sm text-slate-900 dark:text-white outline-none focus:border-indigo-500"
                />
                <button 
                  type="submit"
                  disabled={isChatLoading || !chatInput.trim()}
                  className="px-5 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-semibold rounded-xl flex items-center gap-2 transition-colors shrink-0"
                >
                  <Send className="w-4 h-4" />
                  Yuborish
                </button>
              </form>
            </div>
          </div>
        )}

        {/* ================= PARENT DASHBOARD VIEW ================= */}
        {activeTab === 'parent' && (
          <div className="max-w-5xl mx-auto space-y-8">
            <div className="space-y-2">
              <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white">
                Ota-onalar paneli 👨‍👩‍👧‍👦 ({currentUser.firstName} {currentUser.lastName})
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Telefon: {currentUser.phone} | Email: {currentUser.email} | Login: {currentUser.username}
              </p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm space-y-2">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-semibold uppercase">Jami to'plangan XP</span>
                  <Star className="w-5 h-5 text-indigo-500 fill-indigo-500" />
                </div>
                <div className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  {xp} <span className="text-xs font-medium text-slate-500">XP</span>
                </div>
                <p className="text-[11px] text-emerald-600 font-medium">Faollik darajasi</p>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm space-y-2">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-semibold uppercase">Kunlik seriya</span>
                  <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
                </div>
                <div className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  {streak} <span className="text-xs font-medium text-slate-500">kun ketma-ket</span>
                </div>
                <p className="text-[11px] text-amber-600 font-medium">Odat shakllangan 🔥</p>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm space-y-2">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-semibold uppercase">Tugallangan darslar</span>
                  <BookOpen className="w-5 h-5 text-emerald-500" />
                </div>
                <div className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  {completedLessons.length} <span className="text-xs font-medium text-slate-500">ta mavzu</span>
                </div>
                <p className="text-[11px] text-emerald-600 font-medium">O'sish sur'ati barqaror</p>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl shadow-sm space-y-2">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-semibold uppercase">O'qish vaqti (Bugun)</span>
                  <Clock className="w-5 h-5 text-violet-500" />
                </div>
                <div className="text-3xl font-extrabold text-slate-900 dark:text-white tabular-nums">
                  {completedLessons.length * 15} <span className="text-xs font-medium text-slate-500">daqiqa</span>
                </div>
                <p className="text-[11px] text-violet-600 font-medium">Telefon o'yinlaridan afzal</p>
              </div>
            </div>

            {/* Recommendations for Parents */}
            <div className="bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 rounded-3xl p-8 space-y-4">
              <div className="flex items-center gap-3">
                <Lightbulb className="w-6 h-6 text-amber-500" />
                <h3 className="text-lg font-bold text-indigo-900 dark:text-indigo-200">
                  Ota-onalar uchun tavsiyalar
                </h3>
              </div>
              <ul className="space-y-3 text-sm text-slate-700 dark:text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-indigo-600">1.</span>
                  <span>Farzandingizga har kuni kechqurun 20-30 daqiqa ZiyoKids orqali o'qish uchun odat yarating.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-indigo-600">2.</span>
                  <span>Qiyin chiqqan masalalar bo'yicha AI Ustozdan birgalikda foydalanib savollar bering.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-indigo-600">3.</span>
                  <span>To'plangan XP ballar evaziga kichik rag'batlantiruvchi sovg'alar ulashing!</span>
                </li>
              </ul>
            </div>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 py-6 px-6 text-center text-xs text-slate-500 dark:text-slate-400">
        © 2026 ZiyoKids — Bolalar uchun aqlli ta'lim platformasi. Barcha huquqlar himoyalangan.
      </footer>

    </div>
  );
}
